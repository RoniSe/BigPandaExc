# MongoDB Java Quickstart

Various quick starts for using mongodb with java - check the different branches for different versions of the driver

To run:  `./gradlew quickStart`
or to supply a different connection string: `./gradlew quickStart -PconnectionString=mongodb://localhost`

Source code is in `./src/main/quickstart/QuickStart.java`
Github source: https://github.com/rozza/mongo-java-quickstart
